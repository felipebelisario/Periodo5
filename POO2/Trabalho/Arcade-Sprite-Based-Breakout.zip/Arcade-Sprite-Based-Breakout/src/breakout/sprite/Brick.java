package breakout.sprite;

import javax.swing.ImageIcon;

import spriteframework.sprite.BadSprite;

public class Brick extends BadSprite {

    private boolean destroyed;

    public Brick(int x, int y) {
        
        initBrick(x, y);
    }
    
    private void initBrick(int x, int y) {
        
        this.x = x;
        this.y = y;
        
        destroyed = false;

        loadImage();
        getImageDimensions();
    }
    
    private void loadImage() {
        
        ImageIcon ii = new ImageIcon("src/resources/brick.png");
        image = ii.getImage();        
    }
}
