# Java Space Invaders
Java Space Invaders game clone source code 

http://zetcode.com/tutorials/javagamestutorial/spaceinvaders/

![Space Invaders screenshot](spaceinvaders.png)

Available under 2-Clause BSD License https://opensource.org/licenses/BSD-2-Clause  
