package abstractFactory;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JToolBar;

//Creates components and places them appropriately in the frame

public class EditorApplication {
	public EditorApplication(EditorFactory factory) {
		this.factory = factory;

		/** ***************** */
		//call Factory Methods to create products
		frame = factory.createFrame();
		pane = factory.createDesktopPane();
		listener = factory.createActionListener(pane);
		menuBar = factory.createMenuBar(listener);
		toolBar = factory.createToolBar(listener);
		windowAdapter = factory.createWindowAdapter(pane);

		//add components to frame
		frame.setJMenuBar(menuBar);
		frame.addWindowListener(windowAdapter);
		frame.getContentPane().add(toolBar, "North");
		frame.getContentPane().add(pane);

		frame.show(); //display the frame
	}

	private JFrame frame;

	private JMenuBar menuBar;

	private JToolBar toolBar;

	private WindowAdapter windowAdapter;

	private JDesktopPane pane;

	private ActionListener listener;

	/** ***************** */
	//Factory for creating editor components
	private EditorFactory factory;

	public static void main(String[] args) {
		EditorApplication editor = new EditorApplication(
				new TextEditorFactory());
	}
}