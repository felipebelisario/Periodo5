package breakout;

import javax.swing.JFrame;


import spriteframework.AbstractBoard;
import spriteframework.MainFrame;

import java.awt.EventQueue;

public class BreakoutGame extends MainFrame {

    public BreakoutGame() {    
        super("Breakout");
    }
    
	protected  AbstractBoard createBoard() {
		return new BreakoutBoard();
	}
    
    

    public static void main(String[] args) {
        
        EventQueue.invokeLater(() -> {

            new BreakoutGame();
        });
    }
}
