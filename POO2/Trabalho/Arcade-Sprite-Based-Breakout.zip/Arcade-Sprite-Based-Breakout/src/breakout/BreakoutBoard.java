package breakout;

import javax.swing.JPanel;
import javax.swing.Timer;

import breakout.sprite.Ball;
import breakout.sprite.Brick;
import breakout.sprite.Commons;
import breakout.sprite.Paddle;
import spriteframework.AbstractBoard;
import spriteframework.sprite.Player;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class BreakoutBoard extends AbstractBoard {
    private Ball ball;

    public BreakoutBoard() {
        super();
    }

    protected Player createPlayer() {
    	return new Paddle();
    }
 

	protected void createOtherSprites() {
		ball = new Ball();
	}

	protected void createBadSprites() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 6; j++) {
                badSprites.add(new Brick(j * 40 + 30, i * 10 + 50));
            }
        }
	}


//    private void drawObjects(Graphics2D g2d) {
//
    protected void drawOtherSprites(Graphics g) {

        g.drawImage(ball.getImage(), ball.getX(), ball.getY(),
                ball.getImageWidth(), ball.getImageHeight(), this);
    }
        //        g2d.drawImage(paddle.getImage(), paddle.getX(), paddle.getY(),
//                paddle.getImageWidth(), paddle.getImageHeight(), this);
//
    protected void drawBadSprites(Graphics g) {
        for (int i = 0; i < Commons.N_OF_BRICKS; i++) {

            if (!badSprites.get(i).isDestroyed()) {

                g.drawImage(badSprites.get(i).getImage(), badSprites.get(i).getX(),
                		badSprites.get(i).getY(), badSprites.get(i).getImageWidth(),
                		badSprites.get(i).getImageHeight(), this);
            }
        }
    }




    protected void update() {

        ball.move();
        for (Player player: players) 
        	player.act();
        checkCollision();
        repaint();
    }

    private void stopGame() {

        inGame = false;
        timer.stop();
    }

    protected void processOtherSprites(Player player, KeyEvent e) {}

    private void checkCollision() {

        if (ball.getRect().getMaxY() > Commons.BOTTOM_EDGE) {

            stopGame();
        }

        for (int i = 0, j = 0; i < Commons.N_OF_BRICKS; i++) {

            if (badSprites.get(i).isDestroyed()) {

                j++;
            }

            if (j == Commons.N_OF_BRICKS) {

                message = "Victory";
                stopGame();
            }
        }

        if ((ball.getRect()).intersects(players.get(0).getRect())) {

            int paddleLPos = (int) players.get(0).getRect().getMinX();
            int ballLPos = (int) ball.getRect().getMinX();

            int first = paddleLPos + 8;
            int second = paddleLPos + 16;
            int third = paddleLPos + 24;
            int fourth = paddleLPos + 32;

            if (ballLPos < first) {

                ball.setXDir(-1);
                ball.setYDir(-1);
            }

            if (ballLPos >= first && ballLPos < second) {

                ball.setXDir(-1);
                ball.setYDir(-1 * ball.getYDir());
            }

            if (ballLPos >= second && ballLPos < third) {

                ball.setXDir(0);
                ball.setYDir(-1);
            }

            if (ballLPos >= third && ballLPos < fourth) {

                ball.setXDir(1);
                ball.setYDir(-1 * ball.getYDir());
            }

            if (ballLPos > fourth) {

                ball.setXDir(1);
                ball.setYDir(-1);
            }
        }

        for (int i = 0; i < Commons.N_OF_BRICKS; i++) {

            if ((ball.getRect()).intersects(badSprites.get(i).getRect())) {

                int ballLeft = (int) ball.getRect().getMinX();
                int ballHeight = (int) ball.getRect().getHeight();
                int ballWidth = (int) ball.getRect().getWidth();
                int ballTop = (int) ball.getRect().getMinY();

                Point pointRight = new Point(ballLeft + ballWidth + 1, ballTop);
                Point pointLeft = new Point(ballLeft - 1, ballTop);
                Point pointTop = new Point(ballLeft, ballTop - 1);
                Point pointBottom = new Point(ballLeft, ballTop + ballHeight + 1);

                if (!badSprites.get(i).isDestroyed()) {

                    if (badSprites.get(i).getRect().contains(pointRight)) {

                        ball.setXDir(-1);
                    } else if (badSprites.get(i).getRect().contains(pointLeft)) {

                        ball.setXDir(1);
                    }

                    if (badSprites.get(i).getRect().contains(pointTop)) {

                        ball.setYDir(1);
                    } else if (badSprites.get(i).getRect().contains(pointBottom)) {

                        ball.setYDir(-1);
                    }

                    badSprites.get(i).die();//.setDestroyed(true);
                }
            }
        }
    }
}
