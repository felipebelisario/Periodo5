package breakout.sprite;

import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;

import spriteframework.sprite.Player;
import spriteframework.sprite.Sprite;

public class Paddle extends Player  {

    private int dx;

    public Paddle() {       
        super();       
    }
    
    
    protected void loadImage() {
        
        ImageIcon ii = new ImageIcon("src/resources/paddle.png");
        image = ii.getImage();        
    }    

    public void move() {

        x += dx;

        if (x <= 0) {

            x = 0;
        }

        if (x >= Commons.BOARD_WIDTH - imageWidth) {

            x = Commons.BOARD_WIDTH - imageWidth;
        }
    }

    public void act() {

        x += dx;

        if (x <= 0) {

            x = 0;
        }

        if (x >= Commons.BOARD_WIDTH - imageWidth) {

            x = Commons.BOARD_WIDTH - imageWidth;
        }
    }

    public void keyPressed(KeyEvent e) {

        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {

            dx = -1;
        }

        if (key == KeyEvent.VK_RIGHT) {

            dx = 1;
        }
    }




}
